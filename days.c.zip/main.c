#include<stdio.h>
int main()
{
    int days,years,weeks,day;
    printf("The number of days are");
    scanf("%d",&days);
    years=days/365;
 weeks=(days%365)/7;
 day=days-(years*365)+(weeks*7);
 printf("The number of years are %d\n",years);

printf("The number of weeks are %d\n",weeks);
    printf("The number of days are %d\n",days);
    return 0;
}
