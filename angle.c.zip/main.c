#include<stdio.h>
int main()
{
    int angle1,angle2,angle3;
    printf("Enter the two angles of the triangle");
    scanf("%d %d",&angle1,&angle2);
    angle3=180-(angle1+angle2);
    printf("The angle of triangle are %d,%d,%d",angle1,angle2,angle3);
    return 0;
}