#include<stdio.h>
int main()
{
    int a[5],i,sum=0;
    for(i=0;i<5;i++)
    {
        printf("enter the element of array:");
        scanf("%d",&a[i]);
    
        
    }
    for(i=0;i<5;i++)
    { 
        if(a[i]<0)
        sum++;
       
    }   
    printf("All negative elements in array:%d\n",sum);
return 0;
    
}