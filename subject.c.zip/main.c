/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   float eng,math,mec,ele,phy,total,average,percentage;
   printf("Enter the marks of the subject");
scanf("%f %f %f %f %f",&eng, &math, &mec, &ele, &phy);
    total=eng+math+mec+ele+phy;
    average=(eng+math+mec+ele+phy)/5;
    percentage=(total/150)*100;
    printf("Total marks are= %f",total);
    printf("Average marks are= %f",average);  
      printf("Percentage marks are= %f",percentage);
      if(percentage>=90)
      {
          printf("Grade A");
      }
      else if(percentage>=80)
{
       printf("Grade B");
}
     else if(percentage>=70)
     {
         printf("Grade C");
     }
     else if(percentage>=60)    
{
    printf("Grade D");
}
else if(percentage>=50)  
    {
        printf("Grade E");
    }
else if(percentage>=40) 
{
      printf("Grade F");
}
else
{
    printf("Fail");
}
    
return 0;    
}
