#include<stdio.h>
int main()
{
    int a[5],i,max;
    for(i=0;i<5;i++)
    {
        printf("enter the element of array:");
        scanf("%d",&a[i]);
    
    }
    max=a[0];
    for(i=0;i<5;i++)
    { 
        if(a[i]>max)
        max=a[i];
       
        
    }printf("max no. in array is:",max);
   
    return 0;
}