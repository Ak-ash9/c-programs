#include<stdio.h>
int main()
{
    int a,b,addition,subtraction,multiplication,division;
    printf("Enter two numbers");
    scanf("%d %d",&a,&b);
    addition=a+b;
    subtraction=a-b;
    multiplication=a*b;
    division=a/b;
    printf("Addition of two numbers=%d\n",addition);
    printf("Subtracttion of two numbers=%d\n",subtraction); 
     printf("Multiplication of two numbers=%d\n",multiplication);
     printf("Divition of two numbers=%d\n",division);
    return 0;
}



