#include<stdio.h>
int main()
{
    int a[10],i,sum=0;
    for(i=0;i<10;i++)
    {
        printf("enter the element of array:");
        scanf("%d",&a[i]);
    
        
    }
    for(i=0;i<10;i++)
    {
        sum=sum+a[i];
    }
    printf("\n sum of the array is =%d",sum);
    return 0;
}
    
    
    