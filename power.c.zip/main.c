#include<stdio.h>

int main()
{
    float english,hindi,math,science,sst,total,average,percentage,grades;
printf("Enter the numbers in English,Hindi,Math,Science,SST");
scanf("%f %f %f %f %f ",&english,&hindi,&math,&science,&sst);
total=(english+hindi+math+science+sst);
average=(total)/5;
percentage=((total)/500)*100;
printf("Total marks=%f",total);
printf("Average marks=%f",average);    
    printf("Percentage =%f",percentage);
    
   return 0; 
    
}