#include<stdio.h>
int main()
{
    int a[5],i;
    for(i=0;i<5;i++)
    {
        printf("enter the element of array:");
        scanf("%d",&a[i]);
    
        
    }
    for(i=0;i<5;i++)
    { 
        if(a[i]<0)
    printf("All negative elements in array:%d\n",a[i]);   
    }   
    
return 0;
    
}
